package main.java.com.mp.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.java.com.mp.qa.base.TestBase;

public class GettingStartedPage extends TestBase{

	//Page Factory - Object Repository
	@FindBy(xpath="//*[@id='MainContent']/div/section/div[1]/button[2]")
	WebElement gettingStarRightArrow;
	
	// Initializing the Page Objects (OR)
	public GettingStartedPage(){
		PageFactory.initElements(driver, this);
	}

	// Define Actions
	public String validateTitle(){
		return driver.getTitle();
	}
	
		// Navigate to Section02 Page
	public FormPage clickOnRightArrow(){
		gettingStarRightArrow.click();
		
		return new FormPage();
	}	
}
