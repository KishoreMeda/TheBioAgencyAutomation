package main.java.com.mp.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.java.com.mp.qa.base.TestBase;

public class DigitalTransPage extends TestBase{

	//Page Factory - Object Repository
	@FindBy(xpath="//*[@id='MainContent']/div/section/div[2]/div/div/div[2]/div/div/span")
	//				 *[@id="MainContent"]/div/section/div[2]/div/div/div[2]/div/div/span

	WebElement rightArrow;
	
	// Initializing the Page Objects (OR)
	public DigitalTransPage(){
		PageFactory.initElements(driver, this);
	}

	// Define Actions
	public String validateTitle(){
		return driver.getTitle();
	}
	
		// Navigate to Section02 Page
	public Section02Page clickOnRightArrow(){
		rightArrow.click();
		
		return new Section02Page();
	}

}
