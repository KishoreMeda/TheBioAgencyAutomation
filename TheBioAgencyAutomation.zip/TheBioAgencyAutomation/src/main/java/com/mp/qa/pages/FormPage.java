package main.java.com.mp.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.java.com.mp.qa.base.TestBase;

public class FormPage extends TestBase{

	//Page Factory - Object Repository
	@FindBy(name="Name")
	WebElement nameTxt;
	
	@FindBy(name="JobTitle")
	WebElement jobTitleTxt;
	
	@FindBy(name="Company")
	WebElement companyTxt;
	
	@FindBy(name="Email")
	WebElement emailTxt;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement submitBtn;
	
	// Initializing the Page Objects (OR)
	public FormPage(){
		PageFactory.initElements(driver, this);
	}
	
	// Define Actions
	public String validateTitle(){
		return driver.getTitle();
	}
	
	public ThanksPage fromSubmit(String name, String title, String company, String mailId){
		nameTxt.sendKeys(name);
		jobTitleTxt.sendKeys(title);
		companyTxt.sendKeys(company);
		emailTxt.sendKeys(mailId);
		
		submitBtn.click();
		
		return new ThanksPage();
	}
}
