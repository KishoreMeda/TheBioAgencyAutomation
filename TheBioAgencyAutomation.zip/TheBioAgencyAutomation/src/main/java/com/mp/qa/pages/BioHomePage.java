package main.java.com.mp.qa.pages;

import main.java.com.mp.qa.base.TestBase;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BioHomePage extends TestBase{
	//Page Factory - Object Repository
	@FindBy(xpath="//*[@id='MainContent']/div/section/div/div[2]/div/ul/li[1]/a/div/span")
	WebElement path;
	
	// Initializing the Page Objects (OR)
	public BioHomePage(){
		PageFactory.initElements(driver, this);
	}
	
	// Define Actions
	public String validateTitle(){
		return driver.getTitle();
	}
	
		// Navigate to DigitalTransformation Page
	public DigitalTransPage clickOnDigitalTrans(){
		path.click();
		
		return new DigitalTransPage();
	}
	//public WebElement 
	//public boolen validate
}
