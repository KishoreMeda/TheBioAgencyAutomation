package main.java.com.mp.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.java.com.mp.qa.base.TestBase;

public class ThanksPage extends TestBase{
	//Page Factory - Object Repository
		//@FindBy(xpath="//*[@id="MainContent"]/div/section/div[2]/div/div/div[2]/div/div/span/span")
		@FindBy(xpath="//a[contains(@class, 'Button']")
		WebElement downloadBtn;
		
		// Initializing the Page Objects (OR)
		public ThanksPage(){
			PageFactory.initElements(driver, this);
		}
		
		// Actions
		public String validateTitle(){
			return driver.getTitle();
		}
}
