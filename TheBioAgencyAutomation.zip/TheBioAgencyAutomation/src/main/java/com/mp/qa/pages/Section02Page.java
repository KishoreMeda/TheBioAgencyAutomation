package main.java.com.mp.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.java.com.mp.qa.base.TestBase;

public class Section02Page extends TestBase{
	//Page Factory - Object Repository
	@FindBy(xpath="//*[@id='MainContent']/div/section/div[1]/button[2]")
	WebElement sectionTwo;
	
	// Initializing the Page Objects (OR)
	public Section02Page(){
		PageFactory.initElements(driver, this);
	}

	// Define Actions
	public String validateTitle(){
		return driver.getTitle();
	}
	
		// Navigate to Section02 Page
	public GettingStartedPage clickOnRightArrow(){
		sectionTwo.click();
		
		return new GettingStartedPage();
	}
}
