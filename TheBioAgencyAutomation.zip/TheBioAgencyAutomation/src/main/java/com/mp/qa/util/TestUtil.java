package main.java.com.mp.qa.util;

public class TestUtil {
	
	// Define constants
	public static long PAGE_LOAD_TIMEOUT = 60;
	public static long IMPLICIT_WAIT = 40;
}
