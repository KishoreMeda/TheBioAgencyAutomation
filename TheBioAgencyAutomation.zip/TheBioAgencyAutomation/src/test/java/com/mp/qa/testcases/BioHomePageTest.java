package test.java.com.mp.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.com.mp.qa.base.TestBase;
import main.java.com.mp.qa.pages.BioHomePage;
import main.java.com.mp.qa.pages.DigitalTransPage;

public class BioHomePageTest extends TestBase{

	BioHomePage bioPage;
	DigitalTransPage digitalTransPage;
	
	public BioHomePageTest(){
		// Initialize super class objects (properties)
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		
		bioPage = new BioHomePage();
	}
	
	@Test(priority=1)
	public void BioHomePageTitleTest(){
		String title = bioPage.validateTitle();
		Assert.assertNotNull(title);
	}
	
	@Test(priority=2)
	public void gotoDigitalTrasformationPage(){
		// Exception Handling if any
		try{
			digitalTransPage = bioPage.clickOnDigitalTrans();
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	
}
