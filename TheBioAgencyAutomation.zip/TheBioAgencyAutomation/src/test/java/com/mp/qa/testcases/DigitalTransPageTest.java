package test.java.com.mp.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.com.mp.qa.base.TestBase;
import main.java.com.mp.qa.pages.BioHomePage;
import main.java.com.mp.qa.pages.DigitalTransPage;
import main.java.com.mp.qa.pages.Section02Page;

public class DigitalTransPageTest extends TestBase{
	BioHomePage bioPage;
	DigitalTransPage dtPage;
	Section02Page sec02Page;
	
	public DigitalTransPageTest(){
		// Initialize super class objects (properties)
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		// Launch HomePage and navigate to Digital Transformation Page
		// Exception Handling if any
		try{	
			bioPage = new BioHomePage();
			dtPage = bioPage.clickOnDigitalTrans();
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	
	@Test(priority=1)
	public void DigitalTransPageTitleTest(){
		String title = dtPage.validateTitle();
		Assert.assertNotNull(title);
	}
	
	@Test(priority=2)
	public void gotoDigitalTrasformationPage(){
		// Exception Handling if any
		try{
			sec02Page = dtPage.clickOnRightArrow();	
		} catch (Exception e){
			e.printStackTrace();
		}
		
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}

}
