package test.java.com.mp.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import main.java.com.mp.qa.base.TestBase;
import main.java.com.mp.qa.pages.BioHomePage;
import main.java.com.mp.qa.pages.DigitalTransPage;
import main.java.com.mp.qa.pages.FormPage;
import main.java.com.mp.qa.pages.GettingStartedPage;
import main.java.com.mp.qa.pages.Section02Page;
import main.java.com.mp.qa.pages.ThanksPage;

public class GettingStartedPageTest extends TestBase{
	BioHomePage bioPage;
	DigitalTransPage dtPage;
	Section02Page sec02Page;
	GettingStartedPage gettingStartedPage;
	FormPage formPage;
	
	public GettingStartedPageTest(){
		// Initialize super class objects (properties)
		super();
	}

	@BeforeMethod
	public void setUp(){
		initialization();
		// Launch HomePage and navigate to Digital Transformation Page
		bioPage = new BioHomePage();
		dtPage = bioPage.clickOnDigitalTrans();
		sec02Page = dtPage.clickOnRightArrow();
		gettingStartedPage = sec02Page.clickOnRightArrow();
	}
	
	@Test(priority=1)
	public void GettingStartedPageTitleTest(){
		String title = gettingStartedPage.validateTitle();
		Assert.assertNotNull(title);
	}
	
	@Test(priority=2)
	public void gotoGettingStartedPage(){
		formPage = gettingStartedPage.clickOnRightArrow();
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	
}
